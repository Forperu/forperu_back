from django.apps import AppConfig


class ScheduleDetailsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.schedule_details'