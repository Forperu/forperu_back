from django.apps import AppConfig


class AbsenceRequestsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.absence_requests'
