from django.apps import AppConfig


class VacationBalancesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.vacation_balances'