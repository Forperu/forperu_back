from django.apps import AppConfig


class OvertimeRequestsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.overtime_requests'