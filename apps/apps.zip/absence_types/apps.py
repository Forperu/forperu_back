from django.apps import AppConfig


class AbsenceTypesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.absence_types'