from django.apps import AppConfig


class EmployeeBenefitsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.employee_benefits'