from django.apps import AppConfig


class EmployeeIncidentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.employee_incidents'